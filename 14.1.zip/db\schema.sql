DROP DATABASE IF EXISTS newsfeed_db;

CREATE DATABASE newsfeed_db;